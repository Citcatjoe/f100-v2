<?php
/**
 *
 * Ventcamp WP Child Theme functions
 *
 * @author Vivaco
 * @license Commercial License
 * @link http://vivaco.com
 * @copyright 2016 Vivaco
 * @package Ventcamp
 * @version 1.0.0
 *
 */
/*** Your custom code goes below ***/
defined('ABSPATH') or die('No direct access');