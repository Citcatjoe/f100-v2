/*** VentcampWP Child Theme ***/

Please install this theme on top of the original Startuply WP theme and modify all styles/funbctions here! Otherwise you wouldn't be able to automatically keep your theme copy up to date.