/*
* README 
* Ventcamp Ventcamp 
* http://startuplywp.com
* Ventcamp - Event and Conference Theme
* Vivaco
* http://vivaco.com
* Version: 2.4.2
*/

This WordPress theme consists of two parts:
1) The PHP code is licensed under the GPL license as is WordPress itself.  You will find a copy of the license text in the same directory as this text file. Or you can read it here:
http://codex.wordpress.org/GPL

2) All other parts of the theme including, but not limited to the CSS code, images, and design are licensed according to the license purchased. More info about your licensing details here:
http://themeforest.net/legal/licences

Send us your feedback or support requests at help@ventcampwp.com - our main one-on-one support email